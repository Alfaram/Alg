# ID решения 69715813

class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        try:
            return self.items.pop()
        except IndexError:
            raise IndexError('Операнды исчерпаны.')


OPERATORS = {'+': lambda x, y: x + y,
             '-': lambda x, y: x - y,
             '*': lambda x, y: x * y,
             '/': lambda x, y: x // y}


def postfix_notation(lines, stack=None, converter=int, operators=OPERATORS):
    stack = Stack() if stack is None else stack
    for element in lines:
        if element in operators:
            element_1, element_2 = stack.pop(), stack.pop()
            stack.push(operators[element](element_2, element_1))
        else:
            try:
                stack.push(converter(element))
            except KeyError:
                raise KeyError(
                    f'Невозможно преобразовать "{element}" в {converter.__name__} или неподдерживаемая операция.')
    return stack.pop()


if __name__ == '__main__':
    print(postfix_notation(input().split()))
