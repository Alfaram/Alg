# ID решения 69584231
# На сервере Python 3.7.3 не получилось сравнить itertools =(

def distance_search(array, desired_number='0'):
    length_array = len(array)
    result = [0] * length_array
    zeroes = [index for index, value in enumerate(array) if
              value == desired_number]
    first = zeroes[0]
    result[:first] = [first - pos for pos in range(first)]
    for prev, next in zip(zeroes, zeroes[1:]):
        for position in range(prev + 1, next):
            result[position] = min(position - prev,
                                   next - position)
# Пытался и этот цикл привести к векторной форме, но что-то не соображу.
# Думаю проблема здесь result[next:prev]
# result[next:prev] = [min(position - prev, next - position) for position
#                  in range(prev + 1, next)]
    last = zeroes[-1]
    result[last:] = [position_last - last for position_last in
                     range(last, length_array)]
    return result


if __name__ == '__main__':
    input()
    print(*distance_search(input().split()))
