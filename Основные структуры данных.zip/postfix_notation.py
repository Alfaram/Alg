# ID решения 69707379
import math


class Stack:
    def __init__(self):
        self.items = []

    def push(self, item):
        self.items.append(item)

    def pop(self):
        return self.items.pop()

    def size(self):
        return len(self.items)


OPERATORS = {'+': lambda x, y: x + y,
             '-': lambda x, y: x - y,
             '*': lambda x, y: x * y,
             '/': lambda x, y: x / y}


def postfix_notation(line, stack=None, operators=OPERATORS):
    stack = Stack() if stack is None else stack
    for element in line:
        if element in operators:
            el1, el2 = stack.pop(), stack.pop()
            try:
                stack.push(math.floor(operators[element](el2, el1)))
            except ZeroDivisionError:
                raise ZeroDivisionError(
                    f'Делить на 0 нельзя "{el2} {element} {el1}".')
        else:
            stack.push(int(element))
    return stack.pop()


if __name__ == '__main__':
    print(postfix_notation(input().split()))
