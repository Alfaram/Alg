# ID решения 69576387

def positions_nearest_number(array, desired_number='0'):
    leng_array = len(array)
    result = [0] * leng_array
    zeroes = [index for index, value in enumerate(array) if
              value == desired_number]
    first_segment = zeroes[0]
    for position_first_segment in range(first_segment):
        result[position_first_segment] = first_segment - position_first_segment
    for position_middle_segment in range(len(zeroes) - 1):
        middle_segment = zeroes[position_middle_segment]
        middle_segment_next = zeroes[position_middle_segment + 1]
        for position in range(middle_segment + 1, middle_segment_next):
            result[position] = min(position - middle_segment,
                                   middle_segment_next - position)
    last_segment = zeroes[-1]
    for position_last_segment in range(last_segment + 1, leng_array):
        result[position_last_segment] = position_last_segment - last_segment
    return result


if __name__ == '__main__':
    leng = input()
    array = [*input().split()]
    print(*positions_nearest_number(array))
