# ID решения 69576717

from collections import Counter


def count_point(number_buttons, array, people=2, aggregate='.'):
    return sum(1 for x in Counter(
        filter(lambda num: num != aggregate, list(array))).values() if
               x <= people * number_buttons)


if __name__ == '__main__':
    number_buttons = int(input())
    array = f'{input()}{input()}{input()}{input()}'
    print(count_point(number_buttons, array))
